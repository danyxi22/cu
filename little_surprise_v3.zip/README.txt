LITTLE SURPRISE — VERSION 3 💗

This is a Progressive Web App (PWA) made to feel like a small iPhone app.

FILES
index.html = page + all customization
manifest.json = app information
sw.js = PWA behavior
icon.svg = Home Screen icon

ADD YOUR GIF
1. Put your GIF in this folder.
2. Rename it: your-gif.gif
3. Done.

ADD YOUR SONG
1. Put your MP3 in this folder.
2. Rename it: your-song.mp3
3. Done.

EDIT THE WORDS
Open index.html in VS Code and search for EDIT 1 through EDIT 7.
Only change the text around those comments.

CHANGE COLORS
At the top of index.html, edit:
--pink
--dark
--bg
--text
--muted

HOW TO TEST
Use VS Code + the Live Server extension. Right-click index.html > Open with Live Server.

HOW TO SEND IT
The project must be hosted online on HTTPS. Upload the ENTIRE folder to a static host such as GitHub Pages, Netlify, or Cloudflare Pages.
You will receive a link. Send that link to her.

HOW SHE INSTALLS IT ON IPHONE
1. Open the link in Safari.
2. Tap Share.
3. Tap Add to Home Screen.
4. Tap Add.
5. The heart icon appears on her Home Screen.
6. Tapping the icon opens it like an app.

IMPORTANT IPHONE AUDIO
The song starts after she taps "Open it 💌". iPhone/Safari normally blocks websites from autoplaying audio before a user interaction.

REPEAT
She can close the app and tap the Home Screen icon again later. The experience starts fresh.

You do NOT need Python or Flask for this project.
